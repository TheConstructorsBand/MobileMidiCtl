# flutter_midi_command_windows

This is the windows specific implementation of [FlutterMidiCommand](https://pub.dev/packages/flutter_midi_command)