import 'dart:ffi';
import 'package:ffi/ffi.dart';
import 'package:win32/win32.dart';

// Define the MIDI class GUID
const String MIDI_CLASS_GUID = '{4D36E96C-E325-11CE-BFC1-08002BE10318}';
const String USB_CLASS_GUID = '{36FC9E60-C465-11CF-8056-444553540000}';
const String AUDIO_CLASS_GUID = '{4D36E96C-E325-11CE-BFC1-08002BE10318}';



class MidiDeviceInfo {
  final int deviceID;
  final String name;
  final int manufacturerID;
  final int productID;
  final int driverVersion;
  final String devicePath;

  MidiDeviceInfo({
    required this.deviceID,
    required this.name,
    required this.manufacturerID,
    required this.productID,
    required this.driverVersion,
    required this.devicePath,
  });

  String get uniqueIdentifier {
    return '$devicePath-$manufacturerID-$productID-$driverVersion-$name';
  }
}


class DeviceUtils {

  
  static String _getDeviceInstanceId(int hDevInfo, Pointer<SP_DEVINFO_DATA> deviceInfoData) {
    final instanceIdBuffer = calloc<Uint16>(1024);
    final result = SetupDiGetDeviceInstanceId(
      hDevInfo,
      deviceInfoData,
      instanceIdBuffer.cast<Utf16>(),
      1024,
      nullptr,
    );

    if (result == 0) {
      calloc.free(instanceIdBuffer);
      print('SetupDiGetDeviceInstanceId ${GetLastError()}');
      return "";
    }

    final instanceId = instanceIdBuffer.cast<Utf16>().toDartString();
    calloc.free(instanceIdBuffer);

    return instanceId;
  }

  static String _getDeviceDescription(int hDevInfo, Pointer<SP_DEVINFO_DATA> deviceInfoData) {
    final descriptionBuffer = calloc<Uint16>(MAX_PATH);
    final requiredSize = calloc<DWORD>();

    final result = SetupDiGetDeviceRegistryProperty(
        hDevInfo,
        deviceInfoData,
        SPDRP.SPDRP_DEVICEDESC,
        nullptr,
        descriptionBuffer.cast<Uint8>(),
        MAX_PATH * 2,
        requiredSize);

    if (result == 0) {
      calloc.free(descriptionBuffer);
      calloc.free(requiredSize);
      print('SetupDiGetDeviceRegistryProperty ${GetLastError()}');
      return "";
    }

    final description = descriptionBuffer.cast<Utf16>().toDartString();
    calloc.free(descriptionBuffer);
    calloc.free(requiredSize);

    return description;
  }


  static String getDeviceRegistryPath(int deviceIndex) {

    // final midiClassGuid = calloc<GUID>()..ref.setGUID(MIDI_CLASS_GUID);
    // final usbClassGuid = calloc<GUID>()..ref.setGUID(USB_CLASS_GUID);
final audioClassGuid = calloc<GUID>()..ref.setGUID(AUDIO_CLASS_GUID);
    

    final hDevInfo = SetupDiGetClassDevs(audioClassGuid, nullptr, 0, SETUP_DI_GET_CLASS_DEVS_FLAGS.DIGCF_PRESENT | SETUP_DI_GET_CLASS_DEVS_FLAGS.DIGCF_ALLCLASSES);


    print("hdevInfo ${hDevInfo}");
    if (hDevInfo == INVALID_HANDLE_VALUE) {

      throw Exception('Failed to get device information set. Error: ${GetLastError()}');
    }

    try {      
      final devInfoData = calloc<SP_DEVINFO_DATA>()..ref.cbSize = sizeOf<SP_DEVINFO_DATA>();

      for (var i = 0;; i++) {
     
        final result = SetupDiEnumDeviceInfo(hDevInfo, i, devInfoData);

        if (result == 0) {
          final lastError = GetLastError();
          if (lastError == WIN32_ERROR.ERROR_NO_MORE_ITEMS) {
            print("no more");
            break;
          } else {
            throw Exception('Failed to get device info. Error: $lastError');
          }
        }


        final deviceInstanceId = _getDeviceInstanceId(hDevInfo, devInfoData);
        final deviceDescription = _getDeviceDescription(hDevInfo, devInfoData);

        print("[$i] deviceInstanceId $deviceInstanceId deviceDescription $deviceDescription");

        calloc.free(devInfoData);

        return "$deviceInstanceId - $deviceDescription";
      }

      throw Exception('No Device registery property found');
    } finally {
      SetupDiDestroyDeviceInfoList(hDevInfo);
    }
  }
}