## 0.1.0

* Cleanup

## 0.0.1-dev.9

* Specify UniversalBle git dependecy


## 0.0.1-dev.8

* Added overrides for network session controls


## 0.0.1-dev.7

* Added BLE Support


## 0.0.1-dev.6

* Split into windows_midi_device.
* Better port enumeration
* Better device monitoring.


## 0.0.1-dev.5

* Added device monitoring, to notify when devices attach/detach


## 0.0.1-dev.4

* Fixed sending using midiOutLongMsg


## 0.0.1-dev.3

* Def update


## 0.0.1-dev.2

* License update


## 0.0.1-dev.1

* First release. No BLE Support, No Virtual Devices
