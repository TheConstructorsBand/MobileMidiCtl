package com.navideck.universal_ble_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
