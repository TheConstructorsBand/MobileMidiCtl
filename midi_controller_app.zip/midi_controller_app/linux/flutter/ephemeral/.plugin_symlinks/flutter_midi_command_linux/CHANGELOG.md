## 0.3.0
- Updated to Flutter 3.10, Dart 3
- Added error messages for missing functionality

## 0.1.4
Updated to latest platform interface

## 0.1.3
Fixed buffer allocation

## 0.1.2
Isolate port close

## 0.1.1
Fixed notification on device disconnect

## 0.1.0
First release with linux support

## 0.0.1
Initial Linux support