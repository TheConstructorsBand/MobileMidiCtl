# flutter_midi_command_linux

This is the Linux specific implementation of [FlutterMidiCommand](https://pub.dev/packages/flutter_midi_command)