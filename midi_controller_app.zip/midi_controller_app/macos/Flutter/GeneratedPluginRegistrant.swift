//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import flutter_midi_command
import universal_ble

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  SwiftFlutterMidiCommandPlugin.register(with: registry.registrar(forPlugin: "SwiftFlutterMidiCommandPlugin"))
  UniversalBlePlugin.register(with: registry.registrar(forPlugin: "UniversalBlePlugin"))
}
