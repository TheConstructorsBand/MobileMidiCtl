//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<flutter_midi_command/FlutterMidiCommandPlugin.h>)
#import <flutter_midi_command/FlutterMidiCommandPlugin.h>
#else
@import flutter_midi_command;
#endif

#if __has_include(<universal_ble/UniversalBlePlugin.h>)
#import <universal_ble/UniversalBlePlugin.h>
#else
@import universal_ble;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlutterMidiCommandPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterMidiCommandPlugin"]];
  [UniversalBlePlugin registerWithRegistrar:[registry registrarForPlugin:@"UniversalBlePlugin"]];
}

@end
